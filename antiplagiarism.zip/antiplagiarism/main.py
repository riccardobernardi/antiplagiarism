from antiplagiarism.util import antiplagiarism


def main():
	antiplagiarism()
	print("----------------")
	antiplagiarism(grams=10)

if __name__ == "__main__":
	main()
