from antiplagiarism.util import antiplagiarism

__all__ = [
    'antiplagiarism',
]